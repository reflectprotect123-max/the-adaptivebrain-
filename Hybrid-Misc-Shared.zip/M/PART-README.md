# Misc and Shared

This package holds material that genuinely spans products or does not belong cleanly to one domain:

- the shared authoritative handoff, decision worktree, formulas, build spec and evidence register;
- Strength-versus-Conditioning product-depth audit;
- categorized archive inventory;
- Everyday Responder research batches and comparison;
- coaching-platform, traceability and evidence-platform research;
- Jason Brown's combined Strength/Conditioning/Longevity source;
- product/technical design, market research and archive limitations.

Nothing here was used merely to balance ZIP sizes. Strength and Conditioning each retain their domain-owned material.
