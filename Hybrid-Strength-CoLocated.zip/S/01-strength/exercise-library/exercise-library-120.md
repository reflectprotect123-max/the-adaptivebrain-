# THE HYBRID ENGINE — 120 Exercise Library

A clean, app-independent catalog of 120 canonical exercises. Meaningful movement variants remain separate; spelling, abbreviation, and export aliases are retained for search and history matching.

## Coverage

| Category | Count |
|---|---:|
| Arms | 7 |
| Cardio | 7 |
| Core | 8 |
| Loaded Carry / Conditioning | 7 |
| Machine / Isolation | 8 |
| Power & Athletic | 12 |
| Prep / Mobility | 2 |
| Shoulders / Isolation | 3 |
| Strength — Hinge | 12 |
| Strength — Horizontal Pull | 11 |
| Strength — Horizontal Push | 13 |
| Strength — Squat | 10 |
| Strength — Unilateral | 8 |
| Strength — Vertical Pull | 6 |
| Strength — Vertical Push | 6 |

## Exercise catalog

### Arms

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 1 | Barbell Curl | arms | accessory | barbell, rack or bench | intermediate | 1 |
| 2 | Cable Tricep Pushdown | arms | accessory | cable station | intermediate | 5 |
| 3 | Dumbbell Curl | arms | accessory | dumbbells, bench optional | intermediate | 0 |
| 4 | Hammer Curl | arms | accessory | free weights or bodyweight | intermediate | 90 |
| 5 | Overhead Tricep Extension | arms | accessory | free weights or bodyweight | intermediate | 0 |
| 6 | Preacher Curl | arms | accessory | free weights or bodyweight | intermediate | 6 |
| 7 | Skull Crusher | arms | accessory | free weights or bodyweight | intermediate | 8 |

### Cardio

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 8 | Assault Bike | conditioning | conditioning | cardio machine | intermediate | 115 |
| 9 | Cycling | conditioning | conditioning | cardio machine | beginner | 0 |
| 10 | Jump Rope | conditioning | conditioning | jump rope | intermediate | 0 |
| 11 | Rowing (Erg) | conditioning | conditioning | cardio machine | intermediate | 0 |
| 12 | Running | conditioning | conditioning | treadmill or outdoors | beginner | 11 |
| 13 | Swimming | conditioning | conditioning | pool | beginner | 0 |
| 14 | SkiErg | conditioning | conditioning | cardio machine | intermediate | 211 |

### Core

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 15 | Ab Wheel Rollout | core | accessory | bodyweight, external load optional | advanced | 0 |
| 16 | Hanging Leg Raise | core | accessory | bodyweight, external load optional | intermediate | 21 |
| 17 | Pallof Press | core | accessory | bodyweight, external load optional | intermediate | 0 |
| 18 | Plank | core | accessory | bodyweight, external load optional | beginner | 9 |
| 19 | Cable Crunch | core | accessory | cable station | intermediate | 2 |
| 20 | Dead Bug | core | accessory | bodyweight, external load optional | beginner | 6 |
| 21 | Side Plank | core | accessory | bodyweight, external load optional | beginner | 29 |
| 22 | Copenhagen Plank | core | accessory | bodyweight, external load optional | advanced | 14 |

### Loaded Carry / Conditioning

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 23 | Battle Ropes | carry | carry | battle ropes | intermediate | 51 |
| 24 | Farmer Walk | carry | carry | dumbbells or kettlebells | beginner | 72 |
| 25 | Sled Push | carry | carry | sled | intermediate | 82 |
| 26 | Suitcase Carry | carry | carry | dumbbells or kettlebells | intermediate | 11 |
| 27 | Sandbag Carry | carry | carry | sandbag | intermediate | 1 |
| 28 | Bear Crawl | carry | carry | dumbbells or kettlebells | intermediate | 0 |
| 29 | Backpack Carry | carry | carry | loaded backpack | intermediate | 0 |

### Machine / Isolation

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 30 | Cable Fly | isolation | accessory | cable station | intermediate | 3 |
| 31 | Calf Raise | isolation | accessory | machine | intermediate | 7 |
| 32 | Leg Curl | isolation | accessory | machine | intermediate | 0 |
| 33 | Leg Extension | isolation | accessory | machine | intermediate | 8 |
| 34 | Pec Deck | isolation | accessory | machine | intermediate | 1 |
| 35 | Adductor Machine | isolation | accessory | machine | beginner | 1 |
| 36 | Seated Leg Curl | isolation | accessory | machine | intermediate | 15 |
| 37 | Hip Abduction Machine | isolation | accessory | machine | beginner | 7 |

### Power & Athletic

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 38 | Box Jump | power | power | box or bench | advanced | 6 |
| 39 | Broad Jump | power | power | free weights or bodyweight | advanced | 207 |
| 40 | Medicine Ball Slam | power | power | medicine ball | intermediate | 0 |
| 41 | Seated Dynamic Jump | power | power | box or bench | intermediate | 0 |
| 42 | Med-Ball Throw | power | power | medicine ball | intermediate | 0 |
| 43 | Kettlebell Swing | power | power | kettlebell | intermediate | 1 |
| 44 | Fast Sit-to-Stand | power | power | free weights or bodyweight | intermediate | 0 |
| 45 | Jump Squat | power | power | free weights or bodyweight | intermediate | 1 |
| 46 | Hang Power Clean | power | power | free weights or bodyweight | advanced | 123 |
| 47 | Dumbbell Snatch | power | power | dumbbells, bench optional | advanced | 14 |
| 48 | Lateral Bound | power | power | free weights or bodyweight | advanced | 3 |
| 49 | Medicine Ball Rotational Throw | power | power | medicine ball | intermediate | 1 |

### Prep / Mobility

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 50 | Scap Push-Up | prep | prep | bodyweight, external load optional | beginner | 206 |
| 51 | Hip Hinge Drill | prep | prep | bodyweight, external load optional | beginner | 0 |

### Shoulders / Isolation

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 52 | Cable Lateral Raise | isolation | accessory | cable station | intermediate | 1 |
| 53 | Lateral Raise | isolation | accessory | free weights or bodyweight | intermediate | 0 |
| 54 | Rear Delt Fly | isolation | accessory | free weights or bodyweight | intermediate | 0 |

### Strength — Hinge

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 55 | Deadlift | hinge | strength | barbell, rack or bench | intermediate | 135 |
| 56 | Good Morning | hinge | strength | barbell, rack or bench | intermediate | 4 |
| 57 | Hip Thrust | hinge | strength | free weights or bodyweight | intermediate | 6 |
| 58 | Nordic Curl | hinge | strength | free weights or bodyweight | advanced | 18 |
| 59 | Romanian Deadlift | hinge | strength | free weights or bodyweight | intermediate | 160 |
| 60 | Sumo Deadlift | hinge | strength | free weights or bodyweight | intermediate | 93 |
| 61 | Trap Bar Deadlift | hinge | strength | trap bar | intermediate | 67 |
| 62 | Block Pull | hinge | strength | barbell, rack or bench | intermediate | 0 |
| 63 | Band Good Morning | hinge | strength | resistance band | intermediate | 0 |
| 64 | DB RDL | hinge | strength | dumbbells, bench optional | intermediate | 116 |
| 65 | B-Stance Romanian Deadlift | hinge | strength | free weights or bodyweight | intermediate | 17 |
| 66 | Cable Pull-Through | hinge | strength | cable station | intermediate | 20 |

### Strength — Horizontal Pull

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 67 | Barbell Row | horizontal_pull | strength | barbell, rack or bench | intermediate | 54 |
| 68 | Cable Row | horizontal_pull | strength | cable station | intermediate | 0 |
| 69 | Chest-Supported Row | horizontal_pull | strength | free weights or bodyweight | intermediate | 2 |
| 70 | Dumbbell Row | horizontal_pull | strength | dumbbells, bench optional | intermediate | 146 |
| 71 | Face Pull | horizontal_pull | strength | cable station | intermediate | 0 |
| 72 | Meadows Row | horizontal_pull | strength | cable station | advanced | 5 |
| 73 | Supinated Barbell Row | horizontal_pull | strength | barbell, rack or bench | intermediate | 1 |
| 74 | T-Bar Row | horizontal_pull | strength | free weights or bodyweight | intermediate | 44 |
| 75 | Inverted Row | horizontal_pull | strength | free weights or bodyweight | intermediate | 14 |
| 76 | Seal Row | horizontal_pull | strength | free weights or bodyweight | intermediate | 3 |
| 77 | Low Cable Row | horizontal_pull | strength | cable station | intermediate | 27 |

### Strength — Horizontal Push

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 78 | Bench Press | horizontal_push | strength | barbell, rack or bench | intermediate | 278 |
| 79 | Close Grip Bench Press | horizontal_push | strength | bodyweight, external load optional | intermediate | 145 |
| 80 | Dip | horizontal_push | strength | bodyweight, external load optional | intermediate | 0 |
| 81 | Dumbbell Bench Press | horizontal_push | strength | dumbbells, bench optional | intermediate | 66 |
| 82 | Incline Bench Press | horizontal_push | strength | bodyweight, external load optional | intermediate | 58 |
| 83 | Low Incline 1 1/4 Dumbbell Bench Press | horizontal_push | strength | dumbbells, bench optional | intermediate | 8 |
| 84 | Push Up | horizontal_push | strength | bodyweight, external load optional | beginner | 39 |
| 85 | Strict Bar Dip | horizontal_push | strength | bodyweight, external load optional | advanced | 12 |
| 86 | Incline DB Press | horizontal_push | strength | dumbbells, bench optional | intermediate | 0 |
| 87 | Dumbbell Press | horizontal_push | strength | dumbbells, bench optional | intermediate | 0 |
| 88 | Machine Press | horizontal_push | strength | machine | beginner | 0 |
| 89 | Dumbbell Floor Press | horizontal_push | strength | dumbbells, bench optional | intermediate | 18 |
| 90 | Deficit Push-Up | horizontal_push | strength | bodyweight, external load optional | intermediate | 8 |

### Strength — Squat

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 91 | Back Squat | squat | strength | barbell, rack or bench | intermediate | 310 |
| 92 | Box Squat | squat | strength | box or bench | intermediate | 56 |
| 93 | Front Squat | squat | strength | barbell, rack or bench | intermediate | 220 |
| 94 | Goblet Squat | squat | strength | free weights or bodyweight | beginner | 37 |
| 95 | Hack Squat | squat | strength | machine | intermediate | 0 |
| 96 | Leg Press | squat | strength | machine | beginner | 17 |
| 97 | Zercher Squat | squat | strength | barbell, rack or bench | advanced | 25 |
| 98 | Tempo Bodyweight Squat | squat | strength | free weights or bodyweight | beginner | 0 |
| 99 | Landmine Squat | squat | strength | landmine | intermediate | 19 |
| 100 | Cyclist Squat | squat | strength | free weights or bodyweight | intermediate | 17 |

### Strength — Unilateral

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 101 | Bulgarian Split Squat | unilateral | strength | bodyweight, external load optional | intermediate | 67 |
| 102 | Reverse Lunge | unilateral | strength | bodyweight, external load optional | intermediate | 10 |
| 103 | Single Leg RDL | unilateral | strength | bodyweight, external load optional | intermediate | 35 |
| 104 | Step Up | unilateral | strength | box or bench | beginner | 0 |
| 105 | Walking Lunge | unilateral | strength | bodyweight, external load optional | intermediate | 6 |
| 106 | Lateral Lunge | unilateral | strength | bodyweight, external load optional | intermediate | 12 |
| 107 | Cossack Squat | unilateral | strength | bodyweight, external load optional | intermediate | 37 |
| 108 | Front-Foot Elevated Reverse Lunge | unilateral | strength | bodyweight, external load optional | intermediate | 22 |

### Strength — Vertical Pull

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 109 | Chin Up | vertical_pull | strength | bodyweight, external load optional | advanced | 23 |
| 110 | Lat Pulldown | vertical_pull | strength | bodyweight, external load optional | intermediate | 66 |
| 111 | Neutral Grip Pulldown | vertical_pull | strength | bodyweight, external load optional | intermediate | 0 |
| 112 | Pronated Strict Pull Up | vertical_pull | strength | bodyweight, external load optional | advanced | 17 |
| 113 | Pull Up | vertical_pull | strength | bodyweight, external load optional | advanced | 71 |
| 114 | Assisted Pull-Up | vertical_pull | strength | bodyweight, external load optional | intermediate | 1 |

### Strength — Vertical Push

| # | Exercise | Pattern | Role | Equipment | Level | Source uses |
|---:|---|---|---|---|---|---:|
| 115 | Arnold Press | vertical_push | strength | bodyweight, external load optional | intermediate | 0 |
| 116 | Landmine Press | vertical_push | strength | landmine | intermediate | 1 |
| 117 | Overhead Press | vertical_push | strength | barbell, rack or bench | intermediate | 0 |
| 118 | Push Press | vertical_push | strength | barbell, rack or bench | intermediate | 64 |
| 119 | Seated DB Overhead Press | vertical_push | strength | dumbbells, bench optional | intermediate | 76 |
| 120 | Z-Press | vertical_push | strength | bodyweight, external load optional | intermediate | 112 |

## Record fields

The JSON and CSV include stable IDs, canonical names, category and movement pattern, training role, equipment, primary and secondary muscles, difficulty, unilateral/compound flags, tracking mode, default prescription guidance, coaching cues, search aliases, raw source aliases, and historical source usage counts.

This is a training reference library, not medical advice.
