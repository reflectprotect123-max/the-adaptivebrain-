# Strength System — Research and Design Consolidation

Updated 12 September 2026. This is the current strength-side product contract. It consolidates decisions scattered across the evidence dossier, Peak Strength/Garage Strength audit, progression research and TrainHeroic source data. It intentionally contains no personal training split.

## Product position

The strength side uses **a consistent framework with flexible exercise slots**. The program defines the movement role, prescription and set architecture; the athlete chooses or receives an allowed exercise for that slot. The logger remains simple while the rules beneath it are exercise-specific and auditable.

The athlete enters only load, completed repetitions and RIR for each working set. There is no pain signal, technique rating, readiness questionnaire or manually entered working max in the normal logger.

## Session framework

A template may contain preparation instructions, a primary strength slot, a secondary squat/hinge/push/pull slot, assistance slots or pairs, optional carry/sled/trunk/isolation work, and recovery-breathing instructions. The framework stays stable while exercise selection, repetition prescription, loading structure and block emphasis can change. A pair remains a pair rather than being relabelled as a circuit.

## Prescription and result remain separate

The coach/program owns exercise, set count, target repetitions or range, target RIR, rest, set architecture and optional load target. The athlete owns completed load, repetitions, RIR and completion state. A suggestion must never rewrite the prescription or historical result. Store its anchor, confidence, rule version, equipment increment and reason.

## First-time exercise rule

When an exercise has never been logged:

1. Show the prescription without inventing a starting weight.
2. The athlete selects and completes the first working-set load.
3. That set becomes a provisional, low-confidence anchor only when load, repetitions and RIR are present.
4. Warm-ups never become anchors.
5. Comparable successful exposures raise confidence over time.

This deliberately differs from Peak Strength's reported use of entered maxes and related-exercise estimates. It avoids false precision and keeps first use simple.

## Within-session suggestion

Compare target RIR with actual RIR and check completion. Apply one bounded action to the next comparable set:

| Result | Default action |
|---|---|
| Target repetitions not completed | Reduce one available equipment step or follow the set-architecture rule |
| Actual RIR at least 2 below target | Reduce one step |
| Actual RIR within approximately 1 of target | Hold |
| Actual RIR at least 2 above target | Increase one step only when the architecture permits |
| Missing load, repetitions or RIR | No automatic adjustment |

These thresholds are product rules pending validation. RIR is useful but has error, especially for unfamiliar exercises, high-repetition work and sets far from failure.

## Set architecture matters

- **Straight sets:** normally hold while effort remains on target; do not force every set upward.
- **Ramping sets:** suggestions may rise toward the intended heavy set.
- **Top set plus back-off:** find the top-set load, then calculate the prescribed back-off from that actual set.
- **Wave loading:** compare like positions across waves and exposures.
- **Technical or speed work:** preserve quality and loading intent; an easy rating does not convert it into maximal strength work.
- **Fixed-load volume:** preserve the common load unless completion or effort requires a change.

A universal “easy means add weight” rule would be wrong because it destroys the intended structure.

## Between-session progression

Within-session adjustment and long-term progression are separate decisions. For the next comparable exposure:

1. Find the most recent successful comparable working exposure for the same exercise and set role.
2. Confirm that prescription and architecture remain comparable.
3. Progress one lever: load, repetitions, sets or density—not several simultaneously.
4. Use the smallest available equipment increment.
5. Hold when evidence is incomplete or mixed.
6. Treat a return after a long lapse as recalibration; do not apply an invented universal percentage reduction.

For a repetition range, double progression is the simplest default: build repetitions within the range at target RIR, then add the smallest load increment and return toward the lower end.

## Exercise identity and recovery

Learning is exercise- and modality-specific. Barbell, dumbbell, machine and bodyweight variations do not automatically share an e1RM. Recovery data may cap suggestion aggressiveness or alter the offered session, but it must not erase earned progression or rewrite historical anchors. Strength adjustment remains driven primarily by the performed set: load, repetitions and RIR.

## Evidence position

RIR/RPE is supported as a practical autoregulation input, but it is not perfectly accurate and has not been proven universally superior to percentage programming. Peak Strength is a useful precedent for responsive set suggestions, exercise-specific estimates and phase-aware loading, but its exact algorithm is not public. The Hybrid Engine therefore uses transparent, bounded rules and labels unvalidated constants honestly.

Primary supporting files:

- `../04-research-audits/Peak-Strength-Garage-Strength-Set-Weight-Suggestion-Evidence-Audit.md`
- `strength-progression-research-and-product-synthesis.md`
- `../01-current-system/hybrid-engine-final-evidence-dossier.md`
- `exercise-library/`
- `../06-trainheroic-source-data/`

## Remaining gaps

- One canonical executable rule table for every supported set architecture.
- Tests covering first use, straight sets, ramps, top/back-off, equipment rounding, missed repetitions and missing RIR.
- A baseline-update policy after repeated successful exposures.
- Shadow-mode evaluation against historical TrainHeroic sessions.
- Coach controls that expose prescription without exposing unnecessary engine complexity to the athlete.

