# Peak Strength and Garage Strength Set-Weight Suggestions

## Executive findings

Peak Strength uses a hybrid load-prescription system rather than a simple fixed percentage or linear progression. The public evidence supports five components:

1. A baseline strength estimate is entered during onboarding, primarily from current bench press, back squat, and clean one-repetition maximums.
2. The app estimates strength for related exercises and updates exercise-specific estimated one-repetition maximums from logged sets.
3. The program phase determines the intended volume, intensity, exercise complexity, and proximity to a selected peak date.
4. Each working set receives a suggested load and a target difficulty.
5. After the set, the athlete records actual load, repetitions, and difficulty. That response changes the next set's suggested weight and informs later workouts.

The exact load-selection equation is not public. Garage Strength does not disclose the initial percentage of estimated 1RM, the transfer coefficients between related exercises, the numerical mapping from its six difficulty labels to RPE or RIR, the size of each next-set adjustment, or the smoothing and safety bounds used across workouts. Any precise reconstruction of those values would be inference, not a confirmed description of Peak Strength.

The broad method is defensible. Research supports RIR/RPE as a practical way to autoregulate resistance-training load, and several interventions have produced results at least comparable with fixed percentage loading. However, Peak Strength's public materials do not provide enough information to validate its proprietary algorithm itself. The evidence supports the design pattern, not the hidden implementation.

## What Peak Strength publicly confirms

### Initial strength baseline

During onboarding, users enter what they believe they can currently lift for one repetition. Garage Strength advises using a current, conservative value rather than a historical lifetime best. If a user does not know a true 1RM, the help page allows a conservative load that could be lifted for one to five repetitions. The stated purpose is to give the app a baseline for its initial weight suggestions; subsequent logged training recalibrates those suggestions.^1

The help documentation says this onboarding strength entry is unavailable to beginners and people selecting the no-gym equipment option. That implies the app must use a different conservative starting rule for those paths, but the alternative rule is not disclosed.^1

### Related-exercise estimates

Peak Strength initially asks for maxes on a small group of major exercises. Garage Strength states that the app estimates maxes for related exercises, and a 2023 update specifically described improving the first-time suggestion for an exercise by factoring performance on related exercises.^2

This is important because a user may have no history for a football-bar press, split squat, safety-bar squat, or other variation. The app appears to transfer information from known lifts into a starting estimate for the new movement. Garage Strength does not publish the exercise relationship map or the conversion ratios.

### Exercise-specific estimated 1RM

After an exercise has been performed, Peak Strength displays an estimated 1RM derived from weights and repetitions logged during workout sets. The heaviest set from each workout is retained in the exercise history. Users can manually create or change an exercise 1RM, and the app also adjusts maxes from training performance.^1,2

Changing an exercise 1RM after a workout has started does not retroactively rebuild that workout's suggestions. The change applies to future exposure; the athlete can manually change the active set weight.^2

### Set-by-set suggestions

The official help page states that every working set receives a suggested weight. The suggestion generally rises from set to set and is determined by the difficulty assigned to the completed set. After adjusting the actual weight and repetitions if necessary, the athlete records difficulty and logs the set. The next set is then presented with a responsive weight suggestion.^1

The 2024 workflow introduced six difficulty responses:

- Very Easy
- Easy
- Medium
- Hard
- Max Effort
- Did Not Complete

The interface shows the intended difficulty and asks whether the completed set matched it. An information tooltip supplies RPE and RIR comparisons, although the public update log does not reproduce the numerical mapping. If a set is marked Did Not Complete, the user enters the repetitions actually completed.^2

The App Store listing continues to describe the feature as auto-regulated weights: the athlete rates each set's difficulty and the app adjusts as training progresses. As of 12 September 2026, the listing showed version 2.16.2; later public release notes mainly describe bug fixes and progress screens rather than a replacement of the load-feedback workflow.^3

### Behaviour following poor or easy performance

The version history for Peak Strength 1.8.0 says the app ensures that weight changes after a set is logged as Did Not Complete or easier than suggested. It also says suggestions are recalculated when the user manually overrides an exercise 1RM. Version 1.7.2 described an update to the algorithms for suggesting repetitions and weight, but no equation was published.^3

For bodyweight exercises, Garage Strength gives a concrete example: if seven pull-ups are prescribed but five are completed and logged as Did Not Complete, the next set will not suggest more than the athlete demonstrated. Later workouts remember the result and attempt to progress the repetitions.^2

### Phase-dependent loading

Peak Strength uses Garage Strength's five-phase parabolic periodization model: Exposure, Comprehension, Ascension, Summit, and Realization. Programs are organized into two- to five-week blocks, with exercises kept stable within a block to permit week-to-week progression.^1,4

Garage Strength describes the broad phase changes as follows:

| Phase | Publicly described loading direction |
|---|---|
| Exposure | High volume, simple movements, conservative introduction |
| Comprehension | Volume and intensity increase; more complex exercises |
| Ascension | Volume decreases while intensity increases |
| Summit | Initial volume reduction, then very high intensity; some power days near or above 90% |
| Realization | Short taper; simple movements, lower volume, then declining load close to competition |

This means the app's suggested set weight cannot be interpreted independently of the programmed phase, exercise, repetitions, and target difficulty. A Hard triple in Summit and a Medium set of eight in Exposure should not use the same percentage or adjustment rule.

## Reconstructed decision flow

The following flow is supported at the conceptual level. Items marked inferred are not published calculations.

| Stage | Confirmed input | Likely function | Certainty |
|---|---|---|---|
| Program creation | Sport/goal, position or focus, experience, equipment, days per week, peak date | Select exercise menu, block sequence, volume and intensity direction | Confirmed |
| Strength initialization | Current major-lift maxes or conservative capacity | Establish starting strength anchors | Confirmed |
| New exercise | Related-exercise history | Estimate initial exercise max or suggested load | Confirmed concept; conversion unknown |
| Workout generation | Exercise, set, reps, phase and target difficulty | Produce the starting weight for each exercise | Confirmed output; equation unknown |
| Set completion | Actual load, actual reps, actual difficulty | Compare intended and achieved effort | Confirmed |
| Next-set update | Difference between intended and achieved difficulty | Increase, hold, or reduce next suggested load | Confirmed direction; thresholds unknown |
| Later workout | Logged sets and updated estimated 1RM | Recalibrate future suggestions and progression | Confirmed concept; time weighting unknown |

Peak Strength therefore looks closer to a bounded feedback controller than a static spreadsheet. The base program supplies the target. Actual set performance supplies an error signal. The next suggestion attempts to reduce the difference between prescribed and experienced difficulty.

That description should not be stretched into a claim that Peak Strength uses a particular formula. The available public material does not reveal whether the next-set change is a percentage, a fixed plate increment, a table, an exercise-specific model, or a combination.

## Evidence audit

### RIR/RPE can represent resistance-training intensity

Zourdos and colleagues developed a resistance-training RPE scale anchored to repetitions in reserve and found strong inverse relationships between movement velocity and RPE/RIR in experienced and novice squatters. They concluded that the scale was practical for regulating daily training load and providing feedback during maximal testing.^5

Ormsbee and colleagues found similarly strong inverse relationships between repetition velocity and RIR-based RPE during bench pressing in experienced and novice participants. This supports the general use of perceived remaining repetitions as an effort signal.^6

More recent research in resistance-trained men and women found mean absolute errors below one repetition when participants estimated 1 or 3 RIR during bench press sets at 75% 1RM. That supports useful accuracy under those specific conditions: trained participants, one exercise, moderate load, and estimates relatively close to failure.^7

### Accuracy is conditional

RIR is not perfectly accurate in every situation. Mansfield and colleagues found that trained men tended to underestimate their remaining repetitions early in a set, with estimates becoming more accurate in later sets and nearer actual failure. Knowing the numerical load or percentage of 1RM did not solve the error.^8

Remmert and colleagues similarly found that RIR predictions improved nearer failure and in later sets across machine-based single- and multi-joint work. Sex and training experience did not explain the error in that study.^9

This matters for Peak Strength. A six-category slider is simple and usable, but categories such as Very Easy and Easy are necessarily less precise than judgments close to failure. A user reporting Hard or Max Effort is providing a more constrained signal than a user reporting Very Easy. The app should therefore make smaller, more conservative upward adjustments when the set is far from failure.

### RIR can prescribe load reliably

Lovegrove and colleagues asked novice-trained men to progressively increase load until sets of 3, 5, or 8 repetitions ended at 1 RIR. Test-retest reliability was high for the bench press and deadlift. Importantly, the load corresponding to the same 1-RIR target differed by repetition scheme: approximately 88%, 84%, and 79% 1RM for deadlift sets of 3, 5, and 8, and 93%, 87%, and 80% for the corresponding bench-press sets.^10

This supports a key principle: load suggestions should be conditional on both target repetitions and target effort. A system should not map Hard to a single percentage without considering rep count and exercise.

### Autoregulation can compete with fixed percentage loading

In a 12-week study of 31 resistance-trained men, Graham and Cleather compared squat training autoregulated by RIR with loading fixed from the pre-test 1RM. Volume and theoretical intensity were matched. Both groups improved, but the RIR group achieved greater front- and back-squat improvements and trained at slightly higher average relative intensities.^11

Helms and colleagues compared percentage-based and RPE-selected loading in trained lifters following periodized programs matched for sets and repetitions. Both methods improved squat and bench press strength and muscle thickness. Between-group differences were not statistically significant, although the RPE group showed a possible small strength advantage.^12

These studies support autoregulation as a legitimate alternative to relying entirely on a stale pre-program 1RM. They do not establish that Peak Strength's specific hidden algorithm is superior, and they do not prove that changing weight after every set is necessary.

### Fixed repetitions-to-percentage tables are imprecise

The maximal repetitions achievable at a given percentage of 1RM vary between exercises and athlete populations. Shimano and colleagues found that repetition capacity at fixed percentages was influenced by the exercise and the amount of muscle mass involved.^13 Richens and Cleather found that endurance runners completed substantially more repetitions than weightlifters at 70% and 80% 1RM, but not at 90%, despite using the same nominal relative loads.^14 These primary studies show why a universal reps-to-percentage chart cannot precisely predict every athlete's capacity.

Peak Strength's use of logged performance and exercise-specific estimated maxes is conceptually preferable to applying a single universal table forever. Its related-exercise estimate is reasonable as a cold-start convenience, but should be treated as low confidence until the user performs the exercise.

## What the evidence does not validate

The available research does not validate the following undocumented Peak Strength components:

- the numerical conversion from Very Easy, Easy, Medium, Hard, Max Effort, and Did Not Complete to RPE/RIR;
- the amount by which the next set increases or decreases;
- whether adjustments differ between barbells, dumbbells, machines, Olympic lifts, and bodyweight exercises;
- whether the algorithm accounts for equipment increments and total versus per-hand dumbbell loading beyond display formatting;
- the exact estimated-1RM equation;
- the transfer ratio from a known lift to a related exercise;
- the number of workouts used to update an exercise max;
- whether old performances decay in importance;
- whether fatigue, work demands, sleep, pain, illness, or conditioning load directly affect the suggested weight;
- whether the app detects erroneous effort ratings or accidental load entries beyond its published input bounds.

The update log mentions an error message above twice the user's estimated 1RM, with exceptions for lighter absolute values and a 1,200-pound ceiling. This is an input-validity guard, not evidence of physiological safety.^2

## Strengths of the Peak Strength approach

1. **Low-friction feedback.** Six plain-language choices are easier for many athletes than asking for exact RPE decimals.
2. **Immediate correction.** A poor starting estimate can be corrected inside the exercise rather than corrupting the whole session.
3. **Exercise-specific learning.** Logged exercise history is more useful than relying solely on three onboarding maxes.
4. **Human override.** The help page repeatedly states that suggestions are optional and can be changed for safety or practical reasons.
5. **Program context.** Load is embedded in phase, exercise and rep prescription rather than treated as an isolated metric.
6. **Cold-start solution.** Related-exercise estimates allow a useful first suggestion when direct history is absent.

## Weaknesses and risks

1. **Algorithmic opacity.** Users and coaches cannot audit the percentage, adjustment size, transfer ratios or estimated-1RM equation.
2. **Coarse difficulty scale.** Six labels improve usability but discard information compared with a well-anchored RPE/RIR scale.
3. **Potential overreaction.** If the system responds strongly to one inaccurate rating, the next load could overshoot or undershoot.
4. **Ascending-set bias.** The help page says suggestions generally rise set to set. That may suit ramping work but is not universally appropriate for straight sets, fatigue-sensitive technique work, or volume accumulation.
5. **Cold-start uncertainty.** Related lifts can differ substantially because of technique, range of motion, equipment and individual leverages.
6. **Readiness gap.** Public documentation confirms set feedback but does not establish that non-training stress or pre-session readiness changes the initial suggestion.
7. **Failure interpretation.** Did Not Complete can arise from excessive load, insufficient rest, pain, technical error, distraction or an unrealistic rep target. Reducing weight is not always the complete solution.

## Ratings

| Dimension | Rating | Judgment |
|---|---:|---|
| User experience | 8.5/10 | Simple enough to use during training and responsive within the exercise |
| Conceptual evidence alignment | 7.5/10 | RIR/RPE autoregulation is supported, but evidence does not validate the proprietary implementation |
| Transparency | 3/10 | Core equations, mappings, adjustment thresholds and confidence rules are not public |
| Cold-start logic | 6/10 | Better than no suggestion, but related-exercise transfer is highly uncertain |
| Suitability for experienced lifters | 8/10 | Experienced users can override bad suggestions and provide useful effort feedback |
| Suitability for beginners | 6.5/10 | Easy interface, but subjective categories and technique limitations can contaminate feedback |
| Suitability during high occupational fatigue | 6/10 | Set feedback can correct the session, but public evidence does not show proactive use of work, sleep or pain data |
| Overall | 7.5/10 | Good design pattern with insufficient transparency to copy blindly |

## Recommended principles for a transparent implementation

The following design is evidence-informed but is not claimed to reproduce Peak Strength's proprietary algorithm.

### 1. Separate the program target from the load suggestion

Every set should store:

- prescribed repetitions;
- target RPE or RIR;
- suggested load;
- actual load;
- actual repetitions;
- actual RPE/RIR;
- completion state;
- equipment increment;
- reason for any adjustment.

For the Hybrid Engine's athlete-facing execution, this is reduced to three entered values: load, completed repetitions and RIR. Prescription data, completion state, suggestion history, equipment increments and adjustment reasons are stored automatically. Pain and technique are not logger signals and do not feed the weight-suggestion algorithm.

### 2. Use a confidence-ranked starting hierarchy

1. Recent successful sets on the same exercise and rep range.
2. Recent same-exercise estimated 1RM derived from lower-repetition sets reasonably close to failure.
3. For a never-before-logged exercise, no pre-set suggestion: the athlete chooses the first prescribed working-set load and the completed set becomes a provisional, low-confidence anchor.
4. An optional athlete-entered load override.

The Hybrid Engine therefore differs deliberately from Peak Strength's documented onboarding approach. It does not require a manually entered max and does not use a related-exercise estimate to populate the first load. Warm-ups are excluded. The first completed working set must include load, actual repetitions and RIR before it can influence the next suggestion. It remains a calibration observation until comparable successful exposures confirm the anchor.

### 3. Compare target effort with actual effort

The next-set decision should use an error band rather than chase tiny subjective differences:

| Outcome | Default response |
|---|---|
| Target achieved within about 0.5 RPE or 1 RIR | Hold the load unless the session explicitly uses ramping sets |
| Clearly easier than target | Increase by the smallest meaningful equipment increment |
| Clearly harder than target but completed | Reduce by one small increment or hold and reduce later volume |
| Repetitions not completed | Reduce load, repetitions, or terminate according to exercise risk and session intent |

These are bounded decision rules, not a universal formula. Adjustments should be smaller for exercises with high technical or injury cost and when the athlete is reporting far from failure.

### 4. Do not force every set to rise

Support distinct loading structures:

- straight sets;
- ramping sets;
- top set plus back-off sets;
- wave loading;
- technical-speed sets;
- fixed-load volume work.

The progression model should preserve the intended structure. A Medium rating during straight sets should not automatically force an increase if the purpose is repeatable volume.

### 5. Keep within-session and between-session learning separate

Within-session adjustments solve today's mismatch. Between-session updates change the exercise model only after checking data quality. A single unusually easy or hard set should not permanently rewrite the estimated max without corroborating performance.

### 6. Add readiness without allowing it to dominate

For a worker with large day-to-day physical demands, pre-session work hours, sleep, soreness, pain and warm-up performance should alter the allowed range around the base suggestion. Wearable scores can provide context but should not independently dictate the load.

## Bottom line

Peak Strength appears to start with an estimated exercise capacity, apply phase- and set-specific targets, then use the athlete's actual load, repetitions and difficulty response to modify the next set and future estimates. That is a sensible autoregulatory architecture.

The exact mathematics are unavailable. The strongest defensible conclusion is that Peak Strength uses a proprietary, difficulty-responsive feedback system informed by estimated 1RM and related-exercise history. It cannot honestly be described as using a known percentage table, a published RPE equation, or a validated machine-learning model.

For the Hybrid Engine, the feature worth borrowing is not Peak Strength's hidden numbers. It is the interaction pattern: give a conservative suggestion, show the intended effort, capture actual effort and completion, make a bounded adjustment, allow manual override, and retain an auditable reason for the change.

## Sources

1. Garage Strength. [Peak Strength Help Page](https://www.garagestrength.com/pages/peak-strength-help). Accessed 12 September 2026.
2. Garage Strength. [Peak Strength Update Log](https://www.garagestrength.com/pages/peak-strength-update-log). Accessed 12 September 2026.
3. Apple App Store. [Peak Strength: Athlete Performance Training](https://apps.apple.com/us/app/peak-strength/id1632549195). Version history observed 12 September 2026.
4. Garage Strength. [Garage Strength Periodization: The Five Blocks](https://www.garagestrength.com/blogs/news/block-periodization). Accessed 12 September 2026.
5. Zourdos MC, Klemp A, Dolan C, et al. [Novel Resistance Training-Specific Rating of Perceived Exertion Scale Measuring Repetitions in Reserve](https://pubmed.ncbi.nlm.nih.gov/26049792/). Journal of Strength and Conditioning Research. 2016;30(1):267-275. doi:10.1519/JSC.0000000000001049.
6. Ormsbee MJ, Carzoli JP, Klemp A, et al. [Efficacy of the Repetitions in Reserve-Based Rating of Perceived Exertion for the Bench Press in Experienced and Novice Benchers](https://pubmed.ncbi.nlm.nih.gov/28301439/). Journal of Strength and Conditioning Research. 2019;33(2):337-345. doi:10.1519/JSC.0000000000001901.
7. Refalo MC, Remmert JF, Pelland JC, et al. [Accuracy of Intraset Repetitions-in-Reserve Predictions During the Bench Press Exercise in Resistance-Trained Male and Female Subjects](https://pubmed.ncbi.nlm.nih.gov/37967832/). Journal of Strength and Conditioning Research. 2024;38(3):e78-e85. doi:10.1519/JSC.0000000000004653.
8. Mansfield SK, Peiffer JJ, Hughes LJ, Scott BR. [Estimating Repetitions in Reserve for Resistance Exercise: An Analysis of Factors Which Impact on Prediction Accuracy](https://pubmed.ncbi.nlm.nih.gov/32881842/). Journal of Strength and Conditioning Research. Published online 2020. doi:10.1519/JSC.0000000000003779.
9. Remmert JF, Laurson KR, Zourdos MC. [Accuracy of Predicted Intraset Repetitions in Reserve in Single- and Multi-Joint Resistance Exercises Among Trained and Untrained Men and Women](https://pubmed.ncbi.nlm.nih.gov/37036795/). Perceptual and Motor Skills. 2023;130(3):1239-1254. doi:10.1177/00315125231169868.
10. Lovegrove S, Hughes LJ, Mansfield SK, Read PJ, Price P, Patterson SD. [Repetitions in Reserve Is a Reliable Tool for Prescribing Resistance Training Load](https://pubmed.ncbi.nlm.nih.gov/36135029/). Journal of Strength and Conditioning Research. 2022;36(10):2696-2700. doi:10.1519/JSC.0000000000003952.
11. Graham T, Cleather DJ. [Autoregulation by Repetitions in Reserve Leads to Greater Improvements in Strength Over a 12-Week Training Program Than Fixed Loading](https://research.stmarys.ac.uk/id/eprint/3067/). Journal of Strength and Conditioning Research. 2021;35(9):2451-2456. doi:10.1519/JSC.0000000000003164.
12. Helms ER, Byrnes RK, Cooke DM, et al. [RPE vs. Percentage 1RM Loading in Periodized Programs Matched for Sets and Repetitions](https://pubmed.ncbi.nlm.nih.gov/29628895/). Frontiers in Physiology. 2018;9:247. doi:10.3389/fphys.2018.00247.
13. Shimano T, Kraemer WJ, Spiering BA, et al. [Relationship Between the Number of Repetitions and Selected Percentages of One Repetition Maximum in Free Weight Exercises in Trained and Untrained Men](https://pubmed.ncbi.nlm.nih.gov/17194239/). Journal of Strength and Conditioning Research. 2006;20(4):819-823. doi:10.1519/R-18195.1.
14. Richens B, Cleather DJ. [The Relationship Between the Number of Repetitions Performed at Given Intensities Is Different in Endurance and Strength Trained Athletes](https://pmc.ncbi.nlm.nih.gov/articles/PMC4042664/). Biology of Sport. 2014;31(2):157-161. doi:10.5604/20831862.1099047.

## Evidence-quality note

A 2020 paper titled *Estimating Repetitions in Reserve in Four Commonly Used Resistance Exercises* was identified during screening but is marked as retracted in PubMed. It was excluded from the conclusions above.
