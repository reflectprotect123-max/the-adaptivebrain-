# TrainHeroic Source Data

This directory contains the recovered TrainHeroic material used as historical source data:

- `trainheroic-session-library.html` — recovered session/workout library.
- `trainheroic-userData-export-2026-07-25.zip` — original user-data export retained intact.
- `trainheroic-rebuilt-workout-history.xlsx` — reconstructed workbook for inspection and analysis.

These are evidence inputs and historical records. They are not automatically treated as the current program, and personal workouts are not copied into the generic strength-system specification.

