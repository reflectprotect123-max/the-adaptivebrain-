# Strength

This package co-locates the Strength-owned material:

- Strength progression, load/repetition/RIR logic and set architecture;
- the 120-exercise library;
- Peak Strength/Garage Strength research;
- original TrainHeroic export, reconstructed workout database and coach-reference material;
- the current Strength source snapshot under `10-src/str/`.

Shared root handoff files are duplicated so this ZIP remains understandable. Conditioning-owned material is in `Hybrid-Conditioning-CoLocated.zip`; mixed and cross-product material is in `Hybrid-Misc-Shared.zip`.
