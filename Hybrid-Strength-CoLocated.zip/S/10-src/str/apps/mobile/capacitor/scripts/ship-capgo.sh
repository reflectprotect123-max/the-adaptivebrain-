#!/usr/bin/env bash
# Ship Hybrid HTML to Capgo dogfood + live. Fails hard without a token.
#
# Usage (repo root):
#   CAPGO_BUNDLE_VERSION=1.0.53 bash apps/mobile/capacitor/scripts/ship-capgo.sh
#
# Token: CAPGO_TOKEN env, repo-root .capgo (gitignored), or handoff.md §0.5 vault.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REPO="$(cd "$ROOT/../../.." && pwd)"
VERSION="${CAPGO_BUNDLE_VERSION:-}"
APP_ID="${CAPGO_APP_ID:-com.hybrid.athlete}"
CHANNELS="${CAPGO_CHANNELS:-dogfood,live}"

bash "$REPO/scripts/rematerialize-capgo-from-vault.sh"
if [[ -z "${CAPGO_TOKEN:-}" && -f "$REPO/.capgo" ]]; then
  CAPGO_TOKEN="$(cat "$REPO/.capgo")"
fi
if [[ -z "${CAPGO_TOKEN:-}" ]]; then
  echo "ship-capgo: FAIL — set CAPGO_TOKEN, create $REPO/.capgo, or restore vault Token in handoff.md" >&2
  exit 1
fi
if [[ -z "$VERSION" ]]; then
  echo "ship-capgo: FAIL — set CAPGO_BUNDLE_VERSION (e.g. 1.0.53)" >&2
  exit 1
fi

cd "$REPO"
bash scripts/sync-athlete-app.sh

cd "$ROOT"
if [[ ! -x node_modules/.bin/cap ]]; then
  npm install --no-fund --no-audit
fi

echo "ship-capgo: upload $VERSION → $APP_ID channels=$CHANNELS"
npx --yes @capgo/cli@latest bundle upload "$APP_ID" \
  --apikey "$CAPGO_TOKEN" \
  --path ../../athlete \
  --channel "$CHANNELS" \
  --bundle "$VERSION" \
  --comment "ship $VERSION"

echo "ship-capgo: pin live → $VERSION"
npx --yes @capgo/cli@latest channel set live "$APP_ID" \
  --apikey "$CAPGO_TOKEN" \
  --bundle "$VERSION"

echo "ship-capgo: pin dogfood → $VERSION"
npx --yes @capgo/cli@latest channel set dogfood "$APP_ID" \
  --apikey "$CAPGO_TOKEN" \
  --bundle "$VERSION"

echo "ship-capgo: done ($VERSION on $CHANNELS)."
