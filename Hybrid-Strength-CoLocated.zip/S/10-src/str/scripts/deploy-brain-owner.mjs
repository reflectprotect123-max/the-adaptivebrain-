#!/usr/bin/env node
/**
 * Deploy WHOOP/Concept2/coach functions to The Brain owner site (thehybridengine1).
 *
 * Stages a flat bundle (no monorepo path prefix in Lambda) and pins @netlify/blobs
 * to a Lambda-compatible major version.
 */
import { cpSync, existsSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { resolveBrainOwnerSiteId } from './brain-owner-site.mjs';

const API = 'https://api.netlify.com/api/v1';
const repo = join(dirname(fileURLToPath(import.meta.url)), '..');
const source = join(repo, 'scripts/brain-owner-coach');
const token = process.env.NETLIFY_AUTH_TOKEN;

function fail(msg) {
  console.error(`deploy-brain-owner: ${msg}`);
  process.exit(1);
}

if (!token) fail('NETLIFY_AUTH_TOKEN required');

const requiredFns = [
  'brain-coach.mjs',
  'whoop-connect.mjs',
  'whoop-callback.mjs',
  'whoop-sync.mjs',
  'integrations-status.mjs',
];

for (const name of requiredFns) {
  if (!existsSync(join(source, 'netlify/functions', name))) {
    fail(`missing netlify/functions/${name}`);
  }
}

async function listSites() {
  const out = [];
  let page = 1;
  for (;;) {
    const res = await fetch(`${API}/sites?page=${page}&per_page=100`, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`listSites ${res.status}: ${text.slice(0, 200)}`);
    const chunk = JSON.parse(text);
    if (!Array.isArray(chunk) || chunk.length === 0) break;
    out.push(...chunk);
    if (chunk.length < 100) break;
    page += 1;
  }
  return out;
}

const sites = await listSites();
const siteId = resolveBrainOwnerSiteId(sites);
if (!siteId) fail('Could not resolve Brain owner site id (thehybridengine1)');

const site = sites.find((s) => s.id === siteId);
const accountId = site?.account_id;
if (!accountId) fail(`No account_id for site ${siteId}`);

async function upsertEnv(key, value, context = 'production') {
  const res = await fetch(
    `${API}/accounts/${accountId}/env/${encodeURIComponent(key)}?site_id=${siteId}`,
    {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ context, value }),
    },
  );
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`env ${key} ${res.status}: ${text.slice(0, 200)}`);
  }
}

await upsertEnv('APP_BASE_URL', 'https://thehybridengine1.netlify.app');
console.log('APP_BASE_URL set on Brain owner site');

const stage = mkdtempSync(join(tmpdir(), 'brain-owner-'));
console.log(`Staging flat deploy bundle at ${stage}`);
for (const rel of ['netlify.toml', 'package.json', 'package-lock.json', 'index.html', 'netlify', 'checks']) {
  const from = join(source, rel);
  if (existsSync(from)) cpSync(from, join(stage, rel), { recursive: true });
}

const npm = spawnSync('npm', ['ci', '--omit=dev', '--no-fund', '--no-audit'], {
  cwd: stage,
  stdio: 'inherit',
});
if (npm.status !== 0) process.exit(npm.status ?? 1);

console.log(`Deploying Brain owner bundle to site=${siteId}`);
const deploy = spawnSync(
  'npx',
  [
    '--yes',
    'netlify-cli@26.2.0',
    'deploy',
    '--prod',
    '--auth',
    token,
    '--site',
    siteId,
    '--dir',
    '.',
    '--functions',
    'netlify/functions',
    '--no-build',
    '--message',
    `Brain owner WHOOP + coach (${process.env.GITHUB_SHA?.slice(0, 7) || 'local'})`,
  ],
  { cwd: stage, stdio: 'inherit', env: { ...process.env, NETLIFY_AUTH_TOKEN: token } },
);

try {
  rmSync(stage, { recursive: true, force: true });
} catch (_) {}

if (deploy.status !== 0) process.exit(deploy.status ?? 1);
console.log('deploy-brain-owner: ok');
