# Source Snapshot Boundary

These are dependency-free reference snapshots, not a combined repository and not proof that the root contract is implemented.

- `eng/`: Engine repository branch `main`, commit `62516ccd9954d9f8446b72a12b566bff6d374334`.
- `str/`: Strength repository branch `main`, commit `7a7027c5c58ac15cfab119a0a1e8a4fac024ea88`.

The short archive folder names are intentional Windows compatibility aliases. They do not rename the original repositories. The long Strength research folder `strength-macrofactor-rp-2026-08-25` is represented as `str/docs/research/smrp/`.

The source is included so the next builder can inspect current schemas, migrations, tests and deployment assumptions. It intentionally excludes `.git`, dependency folders, credentials, generated APKs and other build output.

The current Engine implementation predates several locked decisions in the root handoff. In particular, numeric RPE/cooked/stopped fields, fixed output adjustments, direct split-seconds changes and older daily-zone drafts are not the target contract. Read `../00-HANDOFF.md` and implement against the root `00-*` documents.

Concept2 Logbook OAuth was retired intentionally. Concept2 remains a manual/device-output modality; do not restore the OAuth integration without a new product decision.
