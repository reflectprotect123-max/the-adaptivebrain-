# Hybrid System Complete Handoff

**Start with `00-HANDOFF.md`.** It is the authoritative product handoff. Then read `00-DECISION-WORKTREE.md`, `00-FORMULAS-AND-RULES.md`, `00-BUILD-SPEC.md`, `00-TEST-VECTORS.json`, `00-EVIDENCE-REGISTER.md`, and `00-MANIFEST.md`.

The remaining folders contain the consolidated evidence archive, TrainHeroic source data, Morpheus references, research audits, product design and current Engine/Strength source snapshots. Older documents are provenance; the root `00-*` contract controls whenever wording conflicts.

## Purpose

This is the working evidence pack for the hybrid training system. It contains the researched findings, research audits, traceability material, final system rules, source programs, and the minimum TrainHeroic source data needed to verify historical programming.

It is not a forensic backup of every message. The 12 September gap correction adds the missing dedicated strength, exercise-library and product-design material. See `08-limitations/2026-09-12-archive-gap-audit.md` for the audit boundary.

## Contents

### Latest conditioning consolidation

Read `02-conditioning/Conditioning-research-and-design-consolidated.md` for the later app comparisons, primary studies, target-relative Easy/Medium/Hard rules, progression example, and blue-interval/active-recovery evidence. It supersedes earlier unconditional increase/decrease proposals. The new personal split and personal resting-heart-rate discussion have not been added.

Read `07-wearables-integrations/WHOOP-recovery-to-zone-module-layer.md` for the proposed WHOOP-driven daily dynamic zones and module ceiling. The actual Blue/Green/Red BPM boundaries now move every morning using a transparent, bounded V1 rule; Green permits the scheduled module, Yellow caps at Green, and Red caps at Blue. The document distinguishes Morpheus's confirmed behavior from its unpublished numerical formula and labels our values as a product hypothesis pending validation.

### 01 - Current system

- Final Hybrid Engine evidence dossier in Markdown and PDF.
- Current two-day full-body framework and recommended additions.
- Hybrid Engine operating procedures and system rules.
- Strength-versus-conditioning product-depth audit.

### 01 - Strength

- Current generic strength-system contract with no personal split.
- Progression, autoregulation and regression research synthesis.
- First-use anchoring, within-session suggestions and between-session progression.
- Set-architecture rules for straight sets, ramps, top/back-off, waves, technical work and fixed-load volume.
- The 120-exercise library in Markdown, CSV and JSON forms.

### 02 - Conditioning

- Conditioning evidence reconstruction and 16-week specification.
- Evidence handoff, source manifest, and progression/regression trees.
- A readable compact copy of the original Aerobic 40 source program.

### 03 - Recovery and readiness

- MORPH recovery-system evidence dossier.
- Recovery, progression, and regression evidence audit.
- Readiness research handoff and reading guide.

### Morpheus reference update — 12 September 2026

- `02-conditioning/Morpheus-reference-and-Hybrid-adaptation.md`: reference index for all 12 methods and their adaptation to Easy / Medium / Hard interval feedback, including target-relative adjustments and implementation limits.
- `05-source-programs/morpheus-user-supplied/`: all 14 user-supplied screenshots, preserved unchanged, including two additional captures.
- This is a documented design update. No app code or live machine integration has been implemented.

### 04 - Research audits

- Research batches 01-04 and 06-10. No Batch 05 file existed in the recovered archive.
- Adaptive-evidence bundle, coaching-platform research brief, weekly research handoff, evidence index, and traceability design.
- Peak Strength/Garage Strength set-weight suggestion audit, including the documented app workflow, unknown proprietary calculations, primary RIR/RPE research, evidence ratings, and transparent implementation principles.

### 05 - Source programs

- Jason Brown strength/conditioning/longevity program.
- Built Not Burnt source program.
- Everyday Responder comparison.

These are practitioner/program sources, not automatically high-quality scientific evidence. Their claims should be separated from peer-reviewed or primary-source evidence in the dossiers.

### 06 - TrainHeroic source data

- Latest recovered original TrainHeroic export (25 July 2026).
- Rebuilt workout-history spreadsheet.
- Parsed TrainHeroic session library.

This is historical source data used to verify programming. It is not evidence that a training method is effective by itself.

### 07 - Wearables and integrations

- Reconstructed research/history covering Garmin, TrainingPeaks, TrainHeroic, and related platform questions.

### 08 - Limitations

- Known recovery gaps, missing materials, and access limitations.
- Archive gap audit listing added, excluded and still-unrecoverable material.

### 09 - Product design

- Product and technical architecture.
- Coaching-platform market research covering notation, progression, trust UX and anti-patterns.

## Evidence hierarchy

Use claims in this order:

1. Primary research, consensus statements, and official technical documentation.
2. Research syntheses and evidence audits with traceable citations.
3. Directly observed personal training and workload data.
4. Practitioner programs and coaching frameworks.
5. Product heuristics, inferred rules, and unverified claims.

Practitioner sources and wearable scores should inform decisions but should not be presented as established scientific facts.

## Deliberately excluded

- TrainHeroic UI/UX videos and interface-design ZIPs.
- App prototypes, login/cloud-sync demos, dashboards, and mock-ups.
- Loose workout screenshots already represented in the written system.
- Duplicate PDFs, exports, videos, and images.
- Old intermediate archives and superseded file copies.
- Duplicate or superseded exercise-library exports; the canonical 120-exercise Markdown, CSV and JSON files are included under `01-strength`.
- General conversation-history reconstruction and four-part download instructions.

The complete archival v4 remains the provenance backup. This pack is the focused working evidence set.
